# SaaSify - Professional SaaS Boilerplate

A production-ready SaaS boilerplate built with **HTML**, **Tailwind CSS** (via CDN), and **Vanilla JavaScript**. Ship your SaaS product in days, not months.

![SaaSify](https://img.shields.io/badge/Built_with-HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-v3-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-ES6-F7DF1E?style=for-the-badge&logo=javascript&logoColor=white)

---

## Features

- **Authentication Pages** — Login and Signup with social OAuth buttons (Google, GitHub)
- **Responsive Dashboard** — Collapsible sidebar, top navigation, user dropdown menu
- **Stats Cards** — Revenue, users, sessions, and conversion metrics
- **Pricing Cards** — 3-tier pricing with highlighted "Most Popular" plan
- **Feature Grid** — 6-card feature showcase with icons
- **Profile Settings** — Editable form with avatar, password change, and notification preferences
- **Toast Notifications** — Success, error, and info toast messages
- **Scroll Animations** — Intersection Observer-based fade-in animations
- **Mobile-First** — Fully responsive on all screen sizes
- **Zero Dependencies** — No build tools, no node_modules, no complexity

---

## Project Structure

```
saas-boilerplate/
├── index.html        # Landing page (hero, features, pricing)
├── login.html        # Login page with social OAuth
├── signup.html       # Signup page with terms acceptance
├── dashboard.html    # Dashboard with sidebar, stats, and profile settings
├── style.css         # Custom styles, animations, and UI utilities
├── script.js         # All interactive JavaScript functionality
└── README.md         # This file
```

### File Descriptions

| File | Purpose |
|------|---------|
| `index.html` | Marketing landing page with hero section, 6-card feature grid, and 3-tier pricing section. Includes sticky navigation with mobile hamburger menu. |
| `login.html` | Centered login card with Google/GitHub OAuth buttons, email/password form, and "forgot password" link. |
| `signup.html` | Centered signup card with first/last name fields, email, password strength hint, and terms checkbox. |
| `dashboard.html` | Full dashboard layout with responsive sidebar, top search bar, notification bell, user dropdown, 4 stats cards, revenue chart placeholder, activity feed, and profile settings form. |
| `style.css` | Custom animations (fade-in, slide-in, scale-in), scrollbar styling, form focus states, toast notifications, loading states, and print styles. |
| `script.js` | Handles mobile menu toggle, sidebar open/close, user dropdown, form validation and submission, toast notifications, scroll animations, keyboard shortcuts (Escape to close), and responsive behavior. |

---

## Getting Started

1. Download or clone this repository
2. Open `index.html` in your browser
3. Start customizing

No build step required. Tailwind CSS is loaded via CDN.

---

## Backend Integration

This boilerplate is designed to be **backend-agnostic**. Here's how to connect it to popular backends:

### Option 1: Supabase (Recommended)

1. Create a project at [supabase.com](https://supabase.com)
2. Add the Supabase JS client to your HTML:

```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
```

3. Initialize Supabase in `script.js`:

```javascript
const supabase = window.supabase.createClient(
    'YOUR_SUPABASE_URL',
    'YOUR_SUPABASE_ANON_KEY'
);
```

4. Replace the simulated form handlers with actual Supabase calls:

```javascript
// Login
const { data, error } = await supabase.auth.signInWithPassword({
    email: email,
    password: password
});

// Signup
const { data, error } = await supabase.auth.signUp({
    email: email,
    password: password,
    options: {
        data: { first_name: firstName, last_name: lastName }
    }
});

// Logout
await supabase.auth.signOut();
```

**Supabase provides:**
- Email/password authentication
- Social OAuth (Google, GitHub, etc.)
- Row Level Security (RLS)
- Real-time database
- File storage

### Option 2: Firebase

1. Create a project at [firebase.google.com](https://firebase.google.com)
2. Add Firebase SDK to your HTML:

```html
<script src="https://www.gstatic.com/firebasejs/10.7.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.0/firebase-auth-compat.js"></script>
```

3. Initialize Firebase in `script.js`:

```javascript
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
```

4. Replace form handlers:

```javascript
// Login
await auth.signInWithEmailAndPassword(email, password);

// Signup
await auth.createUserWithEmailAndPassword(email, password);

// Logout
await auth.signOut();
```

### Option 3: Custom Backend (Node.js, PHP, etc.)

Replace the `setTimeout` calls in `script.js` with `fetch` requests:

```javascript
const response = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
});

const data = await response.json();

if (response.ok) {
    localStorage.setItem('token', data.token);
    window.location.href = 'dashboard.html';
} else {
    showToast(data.message, 'error');
}
```

---

## Deployment

### Vercel (Recommended for Static Sites)

1. Push your code to a GitHub repository
2. Go to [vercel.com](https://vercel.com) and sign in with GitHub
3. Click **"New Project"** and import your repository
4. Framework Preset: **Other**
5. Build Command: Leave empty (no build step needed)
6. Output Directory: `.` (root)
7. Click **Deploy**

Your site will be live at `https://your-project.vercel.app`

### Netlify

1. Push your code to a GitHub repository
2. Go to [netlify.com](https://netlify.com) and sign in with GitHub
3. Click **"Add new site"** > **"Import an existing project"**
4. Select your repository
5. Build command: Leave empty
6. Publish directory: `.` (root)
7. Click **"Deploy site"**

Your site will be live at `https://your-site.netlify.app`

### GitHub Pages

1. Push your code to a GitHub repository
2. Go to **Settings** > **Pages**
3. Source: **Deploy from a branch**
4. Branch: `main` / `/ (root)`
5. Click **Save**

Your site will be live at `https://your-username.github.io/repo-name`

### Custom Domain

All platforms above support custom domains. Add a `CNAME` record pointing to your deployment URL.

---

## Customization

### Changing Colors

Edit the Tailwind config in the `<script>` tag of each HTML file:

```javascript
tailwind.config = {
    theme: {
        extend: {
            colors: {
                primary: {
                    50: '#eff6ff',
                    // ... adjust these hex values
                    600: '#2563eb',
                }
            }
        }
    }
}
```

### Adding Pages

1. Create a new `.html` file
2. Copy the navigation from `index.html` or sidebar from `dashboard.html`
3. Link to it from the navigation

### Adding Components

All components are self-contained in the HTML files. To reuse a component:

1. Copy the relevant HTML block
2. Paste it into your page
3. The styles come from Tailwind CDN + `style.css`

---

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile Safari / Chrome on iOS and Android

---

## Performance

- **No build step** — zero compile time
- **Tailwind CDN** — automatically purges unused CSS in production
- **Vanilla JS** — no framework overhead (~5KB total JS)
- **Lazy animations** — Intersection Observer only animates visible elements

---

## License

This boilerplate is provided as-is for use in your projects. You may modify, extend, and distribute it freely.

---

## Support

For issues or questions, refer to the documentation above or modify the codebase to suit your needs. This is a boilerplate — it's designed to be changed.

---

**Built for developers who want to ship fast.**
